# I/O多路复用
I/O 多路复用使得程序能同时监听多个文件描述符，能够提高程序的性能，Linux 下实现 I/O 多路复用的系统调用主要有 select、poll 和 epoll。

# select
主旨思想：
1. 首先要构造一个关于文件描述符的列表，将要监听的文件描述符添加到该列表中。

2. 调用一个系统函数，监听该列表中的文件描述符，直到这些描述符中的一个或者多个进行I/O操作时，该函数才返回。
	a.这个函数是阻塞
	b.函数对文件描述符的检测的操作是由内核完成的
	
3. 在返回时，它会告诉进程有多少（哪些）描述符要进行I/O操作。

```
   // sizeof(fd_set) = 128 1024 
   #include <sys/time.h> 
   #include <sys/types.h> 
   #include <unistd.h> 
   #include <sys/select.h> 
   int select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout); 
   - 参数： 
   	- nfds : 委托内核检测的最大文件描述符的值 + 1 
   	- readfds : 要检测的文件描述符的读的集合，委托内核检测哪些文件描述符的读的属性 
   		- 一般检测读操作 
   		- 对应的是对方发送过来的数据，因为读是被动的接收数据，检测的就是读缓冲区 
   		- 是一个传入传出参数 
   - writefds : 要检测的文件描述符的写的集合，委托内核检测哪些文件描述符的写的属性 
   	- 委托内核检测写缓冲区是不是还可以写数据（不满的就可以写） 
   - exceptfds : 检测发生异常的文件描述符的集合 
   - timeout : 设置的超时时间 
   	struct timeval { 
   		long tv_sec; /* seconds */ 
   		long tv_usec; /* microseconds */ 
   	};
   		- NULL : 永久阻塞，直到检测到了文件描述符有变化 
   		- tv_sec = 0 tv_usec = 0， 不阻塞 
   		- tv_sec > 0 tv_usec > 0， 阻塞对应的时间 
   		- 返回值 :
           	- -1 : 失败 
           	- >0(n) : 检测的集合中有n个文件描述符发生了变化
   // 将参数文件描述符fd对应的标志位设置为0 
   void FD_CLR(int fd, fd_set *set);
   // 判断fd对应的标志位是0还是1， 返回值 ： fd对应的标志位的值，0，返回0， 1，返回1 
   int FD_ISSET(int fd, fd_set *set); 
   // 将参数文件描述符fd 对应的标志位，设置为1 
   void FD_SET(int fd, fd_set *set);
```

## select缺点
1.每次调用select，都需要把fd集合从用户态拷贝到内核态，这个开销在fd很多时会很大
2.同时每次调用select都需要在内核遍历传递进来的所有fd，这个开销在fd很多时也很大
3.select支持的文件描述符数量太小了，默认是1024
4.fds集合不能重用，每次都需要重置

# poll

```
#include <poll.h> 
struct pollfd { 
	int fd; /* 委托内核检测的文件描述符 */ 
	short events; /* 委托内核检测文件描述符的什么事件 */ 
	short revents; /* 文件描述符实际发生的事件 */ 
	};
struct pollfd myfd; 
myfd.fd = 5; 
myfd.events = POLLIN | POLLOUT; 
int poll(struct pollfd *fds, nfds_t nfds, int timeout); 
	- 参数：- fds : 是一个struct pollfd 结构体数组，这是一个需要检测的文件描述符的集合
	- nfds : 这个是第一个参数数组中最后一个有效元素的下标 + 1 
	- timeout : 阻塞时长 
		0 : 不阻塞 
		-1 : 阻塞，当检测到需要检测的文件描述符有变化，解除阻塞 
		>0 : 阻塞的时长 
	- 返回值： 
		-1 : 失败 
		>0（n） : 成功,n表示检测到集合中有n个文件描述符发生变化
```
# epoll

```
#include <sys/epoll.h> 
// 创建一个新的epoll实例。在内核中创建了一个数据，这个数据中有两个比较重要的数据，一个是需要检测的文件描述符的信息（红黑树），还有一个是就绪列表，存放检测到数据发送改变的文件描述符信息（双向链表）。 
int epoll_create(int size); 
	- 参数：size : 目前没有意义了。随便写一个数，必须大于0 
	- 返回值： -1 : 失败 > 0 : 文件描述符，操作epoll实例的
typedef union epoll_data { 
	void *ptr; 
	int fd; 
	uint32_t u32; 
	uint64_t u64; 
	} epoll_data_t; 
struct epoll_event { 
	uint32_t events; /* Epoll events */ 
	epoll_data_t data; /* User data variable */
    };
    常见的Epoll检测事件： 
    - EPOLLIN 
    - EPOLLOUT 
    - EPOLLERR 
// 对epoll实例进行管理：添加文件描述符信息，删除信息，修改信息
int epoll_ctl(int epfd, int op, int fd, struct epoll_event *event); 
	- 参数： 
		- epfd : epoll实例对应的文件描述符 
		- op : 要进行什么操作 
			EPOLL_CTL_ADD: 添加 
			EPOLL_CTL_MOD: 修改 
			EPOLL_CTL_DEL: 删除 
		- fd : 要检测的文件描述符 
		- event : 检测文件描述符什么事情 
// 检测函数 
int epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout); 
	- 参数：
		- epfd : epoll实例对应的文件描述符 
		- events : 传出参数，保存了发送了变化的文件描述符的信息 
		- maxevents : 第二个参数结构体数组的大小 
		- timeout : 阻塞时间 
			- 0 : 不阻塞 - 
			-1 : 阻塞，直到检测到fd数据发生变化，解除阻塞 
			- > 0 : 阻塞的时长（毫秒） 
		- 返回值： 
			- 成功，返回发送变化的文件描述符的个数 > 0 
			- 失败 -1
```

## Epoll 的工作模式
* LT 模式 （水平触发）
	假设委托内核检测读事件 -> 检测fd的读缓冲区
	读缓冲区有数据 - > epoll检测到了会给用户通知
		a.用户不读数据，数据一直在缓冲区，epoll 会一直通知
		b.用户只读了一部分数据，epoll会通知
		c.缓冲区的数据读完了，不通知
	LT（level - triggered）是缺省的工作方式，并且同时支持 block 和 no-block socket。在这种做法中，内核告诉你一个文件描述符是否就绪了，然后你可以对这个就绪的 fd 进行 IO 操作。如果你不作任何操作，内核还是会继续通知你的。
* ET 模式（边沿触发）
	假设委托内核检测读事件 -> 检测fd的读缓冲区
	读缓冲区有数据 - > epoll检测到了会给用户通知
		a.用户不读数据，数据一致在缓冲区中，epoll下次检测的时候就不通知了
		b.用户只读了一部分数据，epoll不通知
		c.缓冲区的数据读完了，不通知
	ET（edge - triggered）是高速工作方式，只支持 no-block socket。在这种模式下，当描述符从未就绪变为就绪时，内核通过epoll告诉你。然后它会假设你知道文件描述符已经就绪，并且不会再为那个文件描述符发送更多的就绪通知，直到你做了某些操作导致那个文件描述符不再为就绪状态了。但是请注意，如果一直不对这个 fd 作 IO 操作（从而导致它再次变成未就绪），内核不会发送更多的通知（only once）。
	ET 模式在很大程度上减少了 epoll 事件被重复触发的次数，因此效率要比 LT 模式高。epoll工作在 ET 模式的时候，必须使用非阻塞套接口，以避免由于一个文件句柄的阻塞读/阻塞写操作把处理多个文件描述符的任务饿死。

# select/poll/epoll
## 调用函数
	select和poll都是一个函数，epoll是一组函数
## 文件描述符数量
	* select通过线性表描述文件描述符集合，文件描述符有上限，一般是1024，但可以修改源码，重新编译内核，不推荐
	* poll是链表描述，突破了文件描述符上限，最大可以打开文件的数目
	* epoll通过红黑树描述，最大可以打开文件的数目，可以通过命令ulimit -n number修改，仅对当前终端有效
## 将文件描述符从用户传给内核
	* select和poll通过将所有文件描述符拷贝到内核态，每次调用都需要拷贝
	* epoll通过epoll_create建立一棵红黑树，通过epoll_ctl将要监听的文件描述符注册到红黑树上
## 内核判断就绪的文件描述符
	* select和poll通过遍历文件描述符集合，判断哪个文件描述符上有事件发生
	* epoll_create时，内核除了帮我们在epoll文件系统里建了个红黑树用于存储以后epoll_ctl传来的fd外，还会再建立一个list链表，用于存储准备就绪的事件，当epoll_wait调用时，仅仅观察这个list链表里有没有数据即可。
	* epoll是根据每个fd上面的回调函数(中断函数)判断，只有发生了事件的socket才会主动的去调用 callback函数，其他空闲状态socket则不会，若是就绪事件，插入list

## 应用程序索引就绪文件描述符
	* select/poll只返回发生了事件的文件描述符的个数，若知道是哪个发生了事件，同样需要遍历
	* epoll返回的发生了事件的个数和结构体数组，结构体包含socket的信息，因此直接处理返回的数组即可
## 工作模式
	* select和poll都只能工作在相对低效的LT模式下
	* epoll则可以工作在ET高效模式，并且epoll还支持EPOLLONESHOT事件，该事件能进一步减少可读、可写和异常事件被触发的次数
## 应用场景
	* 当所有的fd都是活跃连接，使用epoll，需要建立文件系统，红黑书和链表对于此来说，效率反而不高，不如selece和poll
	* 当监测的fd数目较小，且各个fd都比较活跃，建议使用select或者poll
	* 当监测的fd数目非常大，成千上万，且单位时间只有其中的一部分fd处于就绪状态，这个时候使用epoll能够明显提升性能
# ET、LT、EPOLLONESHOT
## LT水平触发模式
* epoll_wait检测到文件描述符有事件发生，则将其通知给应用程序，应用程序可以不立即处理该事件。
* 当下一次调用epoll_wait时，epoll_wait还会再次向应用程序报告此事件，直至被处理
## ET边缘触发模式
* epoll_wait检测到文件描述符有事件发生，则将其通知给应用程序，应用程序必须立即处理该事件
* 必须要一次性将数据读取完，使用非阻塞I/O，读取到出现eagain
## EPOLLONESHOT
* 一个线程读取某个socket上的数据后开始处理数据，在处理过程中该socket上又有新数据可读，此时另一个线程被唤醒读取，此时出现两个线程处理同一个socket
* 我们期望的是一个socket连接在任一时刻都只被一个线程处理，通过epoll_ctl对该文件描述符注册epolloneshot事件，一个线程处理socket时，其他线程将无法处理，当该线程处理完后，需要通过epoll_ctl重置epolloneshot事件
# epoll相关代码

项目中epoll相关代码部分包括非阻塞模式、内核事件表注册事件、删除事件、重置EPOLLONESHOT事件四种。

* 非阻塞模式

```
  int setnonblocking( int fd ) {
      int old_option = fcntl( fd, F_GETFL );
      int new_option = old_option | O_NONBLOCK;
      fcntl( fd, F_SETFL, new_option );
      return old_option;
  }
```
* 内核事件表注册新事件，开启EPOLLONESHOT，针对客户端连接的描述符，listenfd不用开启

  ```
  // 向epoll中添加需要监听的文件描述符
  void addfd( int epollfd, int fd, bool one_shot ) {
      epoll_event event;
      event.data.fd = fd;
      event.events = EPOLLIN | EPOLLRDHUP;
      if(one_shot) 
      {
          // 防止同一个通信被不同的线程处理
          event.events |= EPOLLONESHOT;
      }
      epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &event);
      // 设置文件描述符非阻塞
      setnonblocking(fd);  
  }
  ```
  
* 内核事件表删除事件

  ```
  // 从epoll中移除监听的文件描述符
  void removefd( int epollfd, int fd ) {
      epoll_ctl( epollfd, EPOLL_CTL_DEL, fd, 0 );
      close(fd);
  }
  ```
  
* 重置EPOLLONESHOT事件

  ```
  // 修改文件描述符，重置socket上的EPOLLONESHOT事件，以确保下一次可读时，EPOLLIN事件能被触发
  void modfd(int epollfd, int fd, int ev) {
      epoll_event event;
      event.data.fd = fd;
      event.events = ev | EPOLLET | EPOLLONESHOT | EPOLLRDHUP;
      epoll_ctl( epollfd, EPOLL_CTL_MOD, fd, &event );
  }
  ```
## 服务器接收http请求
浏览器端发出http连接请求，主线程创建http对象接收请求并将所有数据读入对应buffer，将该对象插入任务队列，工作线程从任务队列中取出一个任务进行处理。

```
	http_conn* users = new http_conn[ MAX_FD ];

    int listenfd = socket( PF_INET, SOCK_STREAM, 0 );

    int ret = 0;
    struct sockaddr_in address;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_family = AF_INET;
    address.sin_port = htons( port );

    // 端口复用
    int reuse = 1;
    setsockopt( listenfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof( reuse ) );
    ret = bind( listenfd, ( struct sockaddr* )&address, sizeof( address ) );
    ret = listen( listenfd, 5 );

    // 创建epoll对象，和事件数组，添加
    epoll_event events[ MAX_EVENT_NUMBER ];
    int epollfd = epoll_create( 5 );
    // 添加到epoll对象中
    addfd( epollfd, listenfd, false );
    http_conn::m_epollfd = epollfd;

    while(true) {
        
        int number = epoll_wait( epollfd, events, MAX_EVENT_NUMBER, -1 );
        
        if ( ( number < 0 ) && ( errno != EINTR ) ) {
            printf( "epoll failure\n" );
            break;
        }

        for ( int i = 0; i < number; i++ ) {
            
            int sockfd = events[i].data.fd;
            
            if( sockfd == listenfd ) {
                
                struct sockaddr_in client_address;
                socklen_t client_addrlength = sizeof( client_address );
                int connfd = accept( listenfd, ( struct sockaddr* )&client_address, &client_addrlength );
                
                if ( connfd < 0 ) {
                    printf( "errno is: %d\n", errno );
                    continue;
                } 

                if( http_conn::m_user_count >= MAX_FD ) {
                    close(connfd);
                    continue;
                }
                users[connfd].init( connfd, client_address);

            } else if( events[i].events & ( EPOLLRDHUP | EPOLLHUP | EPOLLERR ) ) {

                users[sockfd].close_conn();

            } else if(events[i].events & EPOLLIN) {

                if(users[sockfd].read()) {
                    pool->append(users + sockfd);
                } else {
                    users[sockfd].close_conn();
                }

            }  else if( events[i].events & EPOLLOUT ) {

                if( !users[sockfd].write() ) {
                    users[sockfd].close_conn();
                }

            }
        }
    }
```

