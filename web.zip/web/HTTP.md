# HTTP报文格式
HTTP报文分为请求报文和响应报文两种，每种报文必须按照特有格式生成，才能被浏览器端识别。其中，浏览器端向服务器发送的为请求报文，服务器处理后返回给浏览器端的为响应报文。
## 请求报文
HTTP请求报文由请求行（request line）、请求头部（header）、空行和请求数据四个部分组成。其中，请求分为两种，GET和POST，具体的：
* GET

```
  GET /562f25980001b1b106000338.jpg HTTP/1.1
  Host:img.mukewang.com
  User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64)
  AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36
  Accept:image/webp,image/*,*/*;q=0.8
  Referer:http://www.imooc.com/
  Accept-Encoding:gzip, deflate, sdch
  Accept-Language:zh-CN,zh;q=0.8
  空行
  请求数据为空
```

* POST

```
  POST / HTTP1.1
  Host:www.wrox.com
  User-Agent:Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727; .NET CLR .0.04506.648; .NET CLR 3.5.21022)
  Content-Type:application/x-www-form-urlencoded
  Content-Length:40
  Connection: Keep-Alive
  空行
  name=Professional%20Ajax&publisher=Wiley
```

* 请求行，用来说明请求类型,要访问的资源以及所使用的HTTP版本。
 GET说明请求类型为GET，/562f25980001b1b106000338.jpg(URL)为要访问的资源，该行的最后一部分说明使用的是HTTP1.1版本。
* 请求头部，紧接着请求行（即第一行）之后的部分，用来说明服务器要使用的附加信息。
	* HOST，给出请求资源所在服务器的域名。
	* User-Agent，HTTP客户端程序的信息，该信息由你发出请求使用的浏览器来定义,并且在每个请求中自动发送等。
	* Accept，说明用户代理可处理的媒体类型。
	* Accept-Encoding，说明用户代理支持的内容编码。
	* Accept-Language，说明用户代理能够处理的自然语言集。
	* Content-Type，说明实现主体的媒体类型。
	* Content-Length，说明实现主体的大小。
	* Connection，连接管理，可以是Keep-Alive或close。
* 空行，请求头部后面的空行是必须的即使第四部分的请求数据为空，也必须有空行。
* 请求数据也叫主体，可以添加任意的其他数据。
## 响应报文
HTTP响应也由四个部分组成，分别是：状态行、消息报头、空行和响应正文。

```
HTTP/1.1 200 OK
Date: Fri, 22 May 2009 06:07:21 GMT
Content-Type: text/html; charset=UTF-8
空行
<html>
      <head></head>
      <body>
            <!--body goes here-->
      </body>
</html>
```

* 状态行，由HTTP协议版本号， 状态码， 状态消息 三部分组成。
* 第一行为状态行，（HTTP/1.1）表明HTTP版本为1.1版本，状态码为200，状态消息为OK。
* 消息报头，用来说明客户端要使用的一些附加信息。
第二行和第三行为消息报头，Date:生成响应的日期和时间；Content-Type:指定了MIME类型的HTML(text/html),编码类型是UTF-8。
* 空行，消息报头后面的空行是必须的。
* 响应正文，服务器返回给客户端的文本信息。空行后面的html部分为响应正文。
## HTTP状态码
HTTP有5种类型的状态码，具体的：
* 1xx：指示信息--表示请求已接收，继续处理。
* 2xx：成功--表示请求正常处理完毕。
	* 200 OK：客户端请求被正常处理。
	* 206 Partial content：客户端进行了范围请求。
* 3xx：重定向--要完成请求必须进行更进一步的操作。
	* 301 Moved Permanently：永久重定向，该资源已被永久移动到新位置，将来任何对该资源的访问都要使用本响应返回的若干个URI之一。
	* 302 Found：临时重定向，请求的资源现在临时从不同的URI中获得。
* 4xx：客户端错误--请求有语法错误，服务器无法处理请求。
	* 400 Bad Request：请求报文存在语法错误。
	* 403 Forbidden：请求被服务器拒绝。
	* 404 Not Found：请求不存在，服务器上找不到请求的资源。
* 5xx：服务器端错误--服务器处理请求出错。
	* 500 Internal Server Error：服务器在执行请求时出现错误。
## 有限状态机
有限状态机，是一种抽象的理论模型，它能够把有限个变量描述的状态变化过程，以可构造可验证的方式呈现出来。比如，封闭的有向图。

有限状态机可以通过if-else,switch-case和函数指针来实现，从软件工程的角度看，主要是为了封装逻辑。

带有状态转移的有限状态机示例代码。

```
STATE_MACHINE(){
    State cur_State = type_A;
    while(cur_State != type_C){
        Package _pack = getNewPackage();
        switch(){
            case type_A:
                process_pkg_state_A(_pack);
                cur_State = type_B;
                break;
            case type_B:
                process_pkg_state_B(_pack);
                cur_State = type_C;
                break;
        }
    }
}
```
该状态机包含三种状态：type_A，type_B和type_C。其中，type_A是初始状态，type_C是结束状态。

状态机的当前状态记录在cur_State变量中，逻辑处理时，状态机先通过getNewPackage获取数据包，然后根据当前状态对数据进行处理，处理完后，状态机通过改变cur_State完成状态转移。

有限状态机一种逻辑单元内部的一种高效编程方法，在服务器编程中，服务器可以根据不同状态或者消息类型进行相应的处理逻辑，使得程序逻辑清晰易懂。
# HTTP处理流程
首先对http报文处理的流程进行简要介绍，然后具体介绍http类的定义和服务器接收http请求的具体过程。
## http报文处理流程
* 浏览器端发出http连接请求，主线程创建http对象接收请求并将所有数据读入对应buffer，将该对象插入任务队列，工作线程从任务队列中取出一个任务进行处理。
* 工作线程取出任务后，调用process_read函数，通过主、从状态机对请求报文进行解析。
* 解析完之后，跳转do_request函数生成响应报文，通过process_write写入buffer，返回给浏览器端。

## http类

```
#ifndef HTTPCONNECTION_H
#define HTTPCONNECTION_H

#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <sys/stat.h>
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdarg.h>
#include <errno.h>
#include "locker.h"
#include <sys/uio.h>

class http_conn
{
public:
    static const int FILENAME_LEN = 200;        // 文件名的最大长度
    static const int READ_BUFFER_SIZE = 2048;   // 读缓冲区的大小
    static const int WRITE_BUFFER_SIZE = 1024;  // 写缓冲区的大小
    
    // HTTP请求方法，这里只支持GET
    enum METHOD {GET = 0, POST, HEAD, PUT, DELETE, TRACE, OPTIONS, CONNECT};
    
    /*
        解析客户端请求时，主状态机的状态
        CHECK_STATE_REQUESTLINE:当前正在分析请求行
        CHECK_STATE_HEADER:当前正在分析头部字段
        CHECK_STATE_CONTENT:当前正在解析请求体
    */
    enum CHECK_STATE { CHECK_STATE_REQUESTLINE = 0, CHECK_STATE_HEADER, CHECK_STATE_CONTENT };
    
    /*
        服务器处理HTTP请求的可能结果，报文解析的结果
        NO_REQUEST          :   请求不完整，需要继续读取客户数据
        GET_REQUEST         :   表示获得了一个完成的客户请求
        BAD_REQUEST         :   表示客户请求语法错误
        NO_RESOURCE         :   表示服务器没有资源
        FORBIDDEN_REQUEST   :   表示客户对资源没有足够的访问权限
        FILE_REQUEST        :   文件请求,获取文件成功
        INTERNAL_ERROR      :   表示服务器内部错误
        CLOSED_CONNECTION   :   表示客户端已经关闭连接了
    */
    enum HTTP_CODE { NO_REQUEST, GET_REQUEST, BAD_REQUEST, NO_RESOURCE, FORBIDDEN_REQUEST, FILE_REQUEST, INTERNAL_ERROR, CLOSED_CONNECTION };
    
    // 从状态机的三种可能状态，即行的读取状态，分别表示
    // 1.读取到一个完整的行 2.行出错 3.行数据尚且不完整
    enum LINE_STATUS { LINE_OK = 0, LINE_BAD, LINE_OPEN };
public:
    http_conn(){}
    ~http_conn(){}
public:
    void init(int sockfd, const sockaddr_in& addr); // 初始化新接受的连接
    void close_conn();  // 关闭连接
    void process(); // 处理客户端请求
    bool read();// 非阻塞读
    bool write();// 非阻塞写
private:
    void init();    // 初始化连接
    HTTP_CODE process_read();    // 解析HTTP请求
    bool process_write( HTTP_CODE ret );    // 填充HTTP应答

    // 下面这一组函数被process_read调用以分析HTTP请求
    HTTP_CODE parse_request_line( char* text );
    HTTP_CODE parse_headers( char* text );
    HTTP_CODE parse_content( char* text );
    HTTP_CODE do_request();
    char* get_line() { return m_read_buf + m_start_line; }
    LINE_STATUS parse_line();

    // 这一组函数被process_write调用以填充HTTP应答。
    void unmap();
    bool add_response( const char* format, ... );
    bool add_content( const char* content );
    bool add_content_type();
    bool add_status_line( int status, const char* title );
    bool add_headers( int content_length );
    bool add_content_length( int content_length );
    bool add_linger();
    bool add_blank_line();

public:
    static int m_epollfd;       // 所有socket上的事件都被注册到同一个epoll内核事件中，所以设置成静态的
    static int m_user_count;    // 统计用户的数量

private:
    int m_sockfd;           // 该HTTP连接的socket和对方的socket地址
    sockaddr_in m_address;
    
    char m_read_buf[ READ_BUFFER_SIZE ];    // 读缓冲区
    int m_read_idx;                         // 标识读缓冲区中已经读入的客户端数据的最后一个字节的下一个位置
    int m_checked_idx;                      // 当前正在分析的字符在读缓冲区中的位置
    int m_start_line;                       // 当前正在解析的行的起始位置

    CHECK_STATE m_check_state;              // 主状态机当前所处的状态
    METHOD m_method;                        // 请求方法

    char m_real_file[ FILENAME_LEN ];       // 客户请求的目标文件的完整路径，其内容等于 doc_root + m_url, doc_root是网站根目录
    char* m_url;                            // 客户请求的目标文件的文件名
    char* m_version;                        // HTTP协议版本号，我们仅支持HTTP1.1
    char* m_host;                           // 主机名
    int m_content_length;                   // HTTP请求的消息总长度
    bool m_linger;                          // HTTP请求是否要求保持连接

    char m_write_buf[ WRITE_BUFFER_SIZE ];  // 写缓冲区
    int m_write_idx;                        // 写缓冲区中待发送的字节数
    char* m_file_address;                   // 客户请求的目标文件被mmap到内存中的起始位置
    struct stat m_file_stat;                // 目标文件的状态。通过它我们可以判断文件是否存在、是否为目录、是否可读，并获取文件大小等信息
    struct iovec m_iv[2];                   // 我们将采用writev来执行写操作，所以定义下面两个成员，其中m_iv_count表示被写内存块的数量。
    int m_iv_count;
};

#endif
```

# 流程图与状态机
==从状态机负责读取报文的一行，主状态机负责对该行数据进行解析==，主状态机内部调用从状态机，从状态机驱动主状态机。
## 主状态机
三种状态，标识解析位置。
* CHECK_STATE_REQUESTLINE，解析请求行
* CHECK_STATE_HEADER，解析请求头
* CHECK_STATE_CONTENT，解析消息体，仅用于解析POST请求
## 从状态机
三种状态，标识解析一行的读取状态。

* LINE_OK，完整读取一行
* LINE_BAD，报文语法有误
* LINE_OPEN，读取的行不完整
# 代码分析-http报文解析
浏览器端发出http连接请求，服务器端主线程创建http对象接收请求并将所有数据读入对应buffer，将该对象插入任务队列后，工作线程从任务队列中取出一个任务进行处理。

各子线程通过process函数对任务进行处理，调用process_read函数和process_write函数分别完成报文解析与报文响应两个任务。

```
// 由线程池中的工作线程调用，这是处理HTTP请求的入口函数
void http_conn::process() {
    // 解析HTTP请求
    HTTP_CODE read_ret = process_read();
    if ( read_ret == NO_REQUEST ) {
    	//注册并监听读事件
        modfd( m_epollfd, m_sockfd, EPOLLIN );
        return;
    }
    
    // 生成响应
    bool write_ret = process_write( read_ret );
    if ( !write_ret ) {
        close_conn();
    }
    //注册并监听写事件
    modfd( m_epollfd, m_sockfd, EPOLLOUT);
}
```

## HTTP_CODE含义
表示HTTP请求的处理结果，在头文件中初始化了八种情形，在报文解析时只涉及到四种。

* NO_REQUEST
	* 请求不完整，需要继续读取请求报文数据
* GET_REQUEST
	* 获得了完整的HTTP请求
* BAD_REQUEST
	* HTTP请求报文有语法错误
* INTERNAL_ERROR
	* 服务器内部错误，该结果在主状态机逻辑switch的default下，一般不会触发
## 解析报文整体流程
process_read通过while循环，将主从状态机进行封装，对报文的每一行进行循环处理。

* 判断条件
	* 主状态机转移到CHECK_STATE_CONTENT，该条件涉及解析消息体
	* 从状态机转移到LINE_OK，该条件涉及解析请求行和请求头部
	* 两者为或关系，当条件为真则继续循环，否则退出
* 循环体
	* 从状态机读取数据
	
	* 调用get_line函数，通过m_start_line将从状态机读取数据间接赋给text
	
	* 主状态机解析text
```
	//m_start_line是行在buffer中的起始位置，将该位置后面的数据赋给text
	//此时从状态机已提前将一行的末尾字符\r\n变为\0\0，所以text可以直接取出完整的行进行解析
    // 主状态机，解析请求
	  http_conn::HTTP_CODE http_conn::process_read() {
	  	//初始化从状态机状态、HTTP请求解析结果
	      LINE_STATUS line_status = LINE_OK;
	      HTTP_CODE ret = NO_REQUEST;
	      char* text = 0;
	      while (((m_check_state == CHECK_STATE_CONTENT) && (line_status == LINE_OK))
	                  || ((line_status = parse_line()) == LINE_OK)) {
	          // 获取一行数据
	          text = get_line();
	          //m_start_line是每一个数据行在m_read_buf中的起始位置
		      //m_checked_idx表示从状态机在m_read_buf中读取的位置
	          m_start_line = m_checked_idx;
	          printf( "got 1 http line: %s\n", text );
	   //主状态机的三种状态转移逻辑
	          switch ( m_check_state ) {
	         	//解析请求行
	              case CHECK_STATE_REQUESTLINE: {
	                  ret = parse_request_line( text );
	                  if ( ret == BAD_REQUEST ) {
	                      return BAD_REQUEST;
	                  }
	                  break;
	              }
	              //解析请求头
	              case CHECK_STATE_HEADER: {
	                  ret = parse_headers( text );
	                  if ( ret == BAD_REQUEST ) {
	                      return BAD_REQUEST;
	                      
	                  } else if ( ret == GET_REQUEST ) {
	                      return do_request();
	                  }
	                  break;
	              }
	              //解析消息体
	              case CHECK_STATE_CONTENT: {
	                  ret = parse_content( text );
	                  if ( ret == GET_REQUEST ) {
	                      return do_request();
	                  }
	                  //解析完消息体即完成报文解析，避免再次进入循环，更新line_status
	                  line_status = LINE_OPEN;
	                  break;
	              }
	              default: {
	                  return INTERNAL_ERROR;
	              }
	          }
	      }
	      return NO_REQUEST;
	  }
```

## 从状态机逻辑
在HTTP报文中，每一行的数据由\r\n作为结束字符，空行则是仅仅是字符\r\n。因此，可以通过查找\r\n将报文拆解成单独的行进行解析，项目中便是利用了这一点。

从状态机负责读取buffer中的数据，将每行数据末尾的\r\n置为\0\0，并更新从状态机在buffer中读取的位置m_checked_idx，以此来驱动主状态机解析。

* 从状态机从m_read_buf中逐字节读取，判断当前字节是否为\r
	* 接下来的字符是\n，将\r\n修改成\0\0，将m_checked_idx指向下一行的开头，则返回LINE_OK
	* 接下来达到了buffer末尾，表示buffer还需要继续接收，返回LINE_OPEN
	* 否则，表示语法错误，返回LINE_BAD
* 当前字节不是\r，判断是否是\n（一般是上次读取到\r就到了buffer末尾，没有接收完整，再次接收时会出现这种情况）
	* 如果前一个字符是\r，则将\r\n修改成\0\0，将m_checked_idx指向下一行的开头，则返回LINE_OK
* 当前字节既不是\r，也不是\n
	* 表示接收不完整，需要继续接收，返回LINE_OPEN

```
//从状态机，用于分析出一行内容
//返回值为行的读取状态，有LINE_OK,LINE_BAD,LINE_OPEN
// 解析一行，判断依据\r\n
//m_read_idx指向缓冲区m_read_buf的数据末尾的下一个字节
//m_checked_idx指向从状态机当前正在分析的字节
http_conn::LINE_STATUS http_conn::parse_line() {
    char temp;
    for ( ; m_checked_idx < m_read_idx; ++m_checked_idx ) {
    //temp为将要分析的字节
        temp = m_read_buf[ m_checked_idx ];
        //如果当前是\r字符，则有可能会读取到完整行
        if ( temp == '\r' ) {
        	//下一个字符达到了buffer结尾，则接收不完整，需要继续接收
            if ( ( m_checked_idx + 1 ) == m_read_idx ) {
                return LINE_OPEN;
            } else if ( m_read_buf[ m_checked_idx + 1 ] == '\n' ) { //下一个字符是\n，将\r\n改为\0\0
                m_read_buf[ m_checked_idx++ ] = '\0';
                m_read_buf[ m_checked_idx++ ] = '\0';
                return LINE_OK;
            }
            //如果都不符合，则返回语法错误
            return LINE_BAD;
        } 
        //如果当前字符是\n，也有可能读取到完整行
	    //一般是上次读取到\r就到buffer末尾了，没有接收完整，再次接收时会出现这种情况
        else if( temp == '\n' )  {   
        //前一个字符是\r，则接收完整
            if( ( m_checked_idx > 1) && ( m_read_buf[ m_checked_idx - 1 ] == '\r' ) ) {
                m_read_buf[ m_checked_idx-1 ] = '\0';
                m_read_buf[ m_checked_idx++ ] = '\0';
                return LINE_OK;
            }
            return LINE_BAD;
        }
    }
     //并没有找到\r\n，需要继续接收
    return LINE_OPEN;
}
```
## 主状态机逻辑
主状态机初始状态是CHECK_STATE_REQUESTLINE，通过调用从状态机来驱动主状态机，在主状态机进行解析前，从状态机已经将每一行的末尾\r\n符号改为\0\0，以便于主状态机直接取出对应字符串进行处理。

* CHECK_STATE_REQUESTLINE
	* 主状态机的初始状态，调用parse_request_line函数解析请求行
	
	* 解析函数从m_read_buf中解析HTTP请求行，获得请求方法、目标URL及HTTP版本号
	
	* 解析完成后主状态机的状态变为CHECK_STATE_HEADER
```
	  // 解析HTTP请求行，获得请求方法，目标URL,以及HTTP版本号
	  http_conn::HTTP_CODE http_conn::parse_request_line(char* text) {
	      // GET /index.html HTTP/1.1
	      //在HTTP报文中，请求行用来说明请求类型,要访问的资源以及所使用的HTTP版本，其中各个部分之间通过\t或空格分隔。
	     //请求行中最先含有空格和\t任一字符的位置并返回
	      m_url = strpbrk(text, " \t"); // 判断第二个参数中的字符哪个在text中最先出现
	      //如果没有空格或\t，则报文格式有误
	      if (! m_url) { 
	          return BAD_REQUEST;
	      }
	      // GET\0/index.html HTTP/1.1
	      //将该位置改为\0，用于将前面数据取出
	      *m_url++ = '\0';    // 置位空字符，字符串结束符
	      //取出数据，并通过与GET比较，以确定请求方式
	      char* method = text;
	      if ( strcasecmp(method, "GET") == 0 ) { // 忽略大小写比较
	          m_method = GET;
	      } else {
	          return BAD_REQUEST;
	      }
	      // /index.html HTTP/1.1
	      // 检索字符串 str1 中第一个不在字符串 str2 中出现的字符下标。
	      m_version = strpbrk( m_url, " \t" );
	      if (!m_version) {
	          return BAD_REQUEST;
	      }
	      *m_version++ = '\0';
	      if (strcasecmp( m_version, "HTTP/1.1") != 0 ) {
	          return BAD_REQUEST;
	      }
	      /**
	       * http://192.168.110.129:10000/index.html
	      */
	      //对请求资源前7个字符进行判断
		  //这里主要是有些报文的请求资源中会带有http://，这里需要对这种情况进行单独处理
	      if (strncasecmp(m_url, "http://", 7) == 0 ) {   
	          m_url += 7;
	          // 在参数 str 所指向的字符串中搜索第一次出现字符 c（一个无符号字符）的位置。
	          m_url = strchr( m_url, '/' );
	      }
	      //一般的不会带有上述两种符号，直接是单独的/或/后面带访问资源
	      if ( !m_url || m_url[0] != '/' ) {
	          return BAD_REQUEST;
	      }
	       //请求行处理完毕，将主状态机转移处理请求头
	      m_check_state = CHECK_STATE_HEADER; // 检查状态变成检查头
	      return NO_REQUEST;
	  }
```
解析完请求行后，主状态机继续分析请求头。在报文中，请求头和空行的处理使用的同一个函数，这里通过判断当前的text首位是不是\0字符，若是，则表示当前处理的是空行，若不是，则表示当前处理的是请求头。

* CHECK_STATE_HEADER
	* 调用parse_headers函数解析请求头部信息
	* 判断是空行还是请求头，若是空行，进而判断content-length是否为0，如果不是0，表明是POST请求，则状态转移到CHECK_STATE_CONTENT，否则说明是GET请求，则报文解析结束。
	* 若解析的是请求头部字段，则主要分析connection字段，content-length字段，其他字段可以直接跳过，各位也可以根据需求继续分析。
	* connection字段判断是keep-alive还是close，决定是长连接还是短连接
	* content-length字段，这里用于读取post请求的消息体长度

```
// 解析HTTP请求的一个头部信息
http_conn::HTTP_CODE http_conn::parse_headers(char* text) {   
    // 遇到空行，表示头部字段解析完毕
    if( text[0] == '\0' ) {
        // 如果HTTP请求有消息体，则还需要读取m_content_length字节的消息体，
        // 状态机转移到CHECK_STATE_CONTENT状态
        if ( m_content_length != 0 ) {
            m_check_state = CHECK_STATE_CONTENT;
            return NO_REQUEST;
        }
        // 否则说明我们已经得到了一个完整的HTTP请求
        return GET_REQUEST;
    } else if ( strncasecmp( text, "Connection:", 11 ) == 0 ) {
        // 处理Connection 头部字段  Connection: keep-alive
        text += 11;
        text += strspn( text, " \t" );
        if ( strcasecmp( text, "keep-alive" ) == 0 ) {
            m_linger = true;
        }
    } else if ( strncasecmp( text, "Content-Length:", 15 ) == 0 ) {
        // 处理Content-Length头部字段
        text += 15;
        text += strspn( text, " \t" );
        m_content_length = atol(text);
    } else if ( strncasecmp( text, "Host:", 5 ) == 0 ) {
        // 处理Host头部字段
        text += 5;
        text += strspn( text, " \t" );
        m_host = text;
    } else {
        printf( "oop! unknow header %s\n", text );
    }
    return NO_REQUEST;
}
```

- CHECK_STATE_CONTENT
	 - 仅用于解析POST请求，调用parse_content函数解析消息体
	- 用于保存post请求消息体，为后面的登录和注册做准备(未做)

```
// 我们没有真正解析HTTP请求的消息体，只是判断它是否被完整的读入了
http_conn::HTTP_CODE http_conn::parse_content( char* text ) {
    if ( m_read_idx >= ( m_content_length + m_checked_idx ) )
    {
        text[ m_content_length ] = '\0';
        return GET_REQUEST;
    }
    return NO_REQUEST;
}
```

# HTTP响应请求报文
浏览器端发出HTTP请求报文，服务器端接收该报文并调用process_read对其进行解析，根据解析结果HTTP_CODE，进入相应的逻辑和模块。

其中，服务器子线程完成报文的解析与响应；主线程监测读写事件，调用read_once和http_conn::write完成数据的读取与发送。

## HTTP_CODE含义
表示HTTP请求的处理结果，在头文件中初始化了八种情形，在报文解析与响应中只用到了七种。
* NO_REQUEST
	* 请求不完整，需要继续读取请求报文数据
	* 跳转主线程继续监测读事件
* GET_REQUEST
	* 获得了完整的HTTP请求
	* 调用do_request完成请求资源映射
* NO_RESOURCE
	* 请求资源不存在
	* 跳转process_write完成响应报文
* BAD_REQUEST
	* HTTP请求报文有语法错误或请求资源为目录
	* 跳转process_write完成响应报文
* FORBIDDEN_REQUEST
	* 请求资源禁止访问，没有读取权限
	* 跳转process_write完成响应报文
* FILE_REQUEST
	* 请求资源可以正常访问
	* 跳转process_write完成响应报文
* INTERNAL_ERROR
	* 服务器内部错误，该结果在主状态机逻辑switch的default下，一般不会触发

## 代码分析
### do_request
```
// 网站的根目录
const char* doc_root = "/home/nowcoder/webserver/resources";
// 当得到一个完整、正确的HTTP请求时，我们就分析目标文件的属性，
// 如果目标文件存在、对所有用户可读，且不是目录，则使用mmap将其
// 映射到内存地址m_file_address处，并告诉调用者获取文件成功
http_conn::HTTP_CODE http_conn::do_request()
{
    // "/home/nowcoder/webserver/resources"
    strcpy( m_real_file, doc_root );
    int len = strlen( doc_root );
    strncpy( m_real_file + len, m_url, FILENAME_LEN - len - 1 );
    // 获取m_real_file文件的相关的状态信息，-1失败，0成功
    if ( stat( m_real_file, &m_file_stat ) < 0 ) {
        return NO_RESOURCE;
    }

    // 判断访问权限
    if ( ! ( m_file_stat.st_mode & S_IROTH ) ) {
        return FORBIDDEN_REQUEST;
    }

    // 判断是否是目录
    if ( S_ISDIR( m_file_stat.st_mode ) ) {
        return BAD_REQUEST;
    }

    // 以只读方式打开文件
    int fd = open( m_real_file, O_RDONLY );
    // 创建内存映射
    m_file_address = ( char* )mmap( 0, m_file_stat.st_size, PROT_READ, MAP_PRIVATE, fd, 0 );
    close( fd );
    return FILE_REQUEST;
}

```

### process_write
根据do_request的返回状态，服务器子线程调用process_write向m_write_buf中写入响应报文。

* add_status_line函数，添加状态行：http/1.1 状态码 状态消息
* add_headers函数添加消息报头，内部调用add_content_length和add_linger函数
	* content-length记录响应报文长度，用于浏览器端判断服务器是否发送完数据
	* connection记录连接状态，用于告诉浏览器端保持长连接
* add_blank_line添加空行
上述涉及的5个函数，均是内部调用add_response函数更新m_write_idx指针和缓冲区m_write_buf中的内容。

```
// 往写缓冲中写入待发送的数据
bool http_conn::add_response( const char* format, ... ) {
	//如果写入内容超出m_write_buf大小则报错
    if( m_write_idx >= WRITE_BUFFER_SIZE ) {
        return false;
    }
     //定义可变参数列表
    va_list arg_list;
    //将变量arg_list初始化为传入参数
    va_start( arg_list, format );
    
    //将数据format从可变参数列表写入缓冲区写，返回写入数据的长度
    int len = vsnprintf( m_write_buf + m_write_idx, WRITE_BUFFER_SIZE - 1 - m_write_idx, format, arg_list );
    //如果写入的数据长度超过缓冲区剩余空间，则报错
    if( len >= ( WRITE_BUFFER_SIZE - 1 - m_write_idx ) ) {
        return false;
    }
    //更新m_write_idx位置
    m_write_idx += len;
    
    //清空可变参列表
    va_end( arg_list );
    return true;
}
//添加状态行
bool http_conn::add_status_line( int status, const char* title ) {
    return add_response( "%s %d %s\r\n", "HTTP/1.1", status, title );
}
//添加消息报头，具体的添加文本长度、连接状态和空行
bool http_conn::add_headers(int content_len) {
    add_content_length(content_len);
    add_content_type();
    add_linger();
    add_blank_line();
}
//添加Content-Length，表示响应报文的长度
bool http_conn::add_content_length(int content_len) {
    return add_response( "Content-Length: %d\r\n", content_len );
}
//添加连接状态，通知浏览器端是保持连接还是关闭
bool http_conn::add_linger()
{
    return add_response( "Connection: %s\r\n", ( m_linger == true ) ? "keep-alive" : "close" );
}
//添加空行
bool http_conn::add_blank_line()
{
    return add_response( "%s", "\r\n" );
}
//添加文本content
bool http_conn::add_content( const char* content )
{
    return add_response( "%s", content );
}
//添加文本类型，这里是html
bool http_conn::add_content_type() {
    return add_response("Content-Type:%s\r\n", "text/html");
}
```

响应报文分为两种，一种是请求文件的存在，通过io向量机制iovec，声明两个iovec，第一个指向m_write_buf，第二个指向mmap的地址m_file_address；一种是请求出错，这时候只申请一个iovec，指向m_write_buf。

* iovec是一个结构体，里面有两个元素，指针成员iov_base指向一个缓冲区，这个缓冲区是存放的是writev将要发送的数据。
* 成员iov_len表示实际写入的长度
```
// 根据服务器处理HTTP请求的结果，决定返回给客户端的内容
bool http_conn::process_write(HTTP_CODE ret) {
    switch (ret)
    {
    	//内部错误，500
        case INTERNAL_ERROR:
        	//状态行
            add_status_line( 500, error_500_title );
            //消息报头
            add_headers( strlen( error_500_form ) );
            if ( ! add_content( error_500_form ) ) {
                return false;
            }
            break;
        
        case BAD_REQUEST:
            add_status_line( 400, error_400_title );
            add_headers( strlen( error_400_form ) );
            if ( ! add_content( error_400_form ) ) {
                return false;
            }
            break;
        //报文语法有误，404
        case NO_RESOURCE:
            add_status_line( 404, error_404_title );
            add_headers( strlen( error_404_form ) );
            if ( ! add_content( error_404_form ) ) {
                return false;
            }
            break;
        //资源没有访问权限，403
        case FORBIDDEN_REQUEST:
            add_status_line( 403, error_403_title );
            add_headers(strlen( error_403_form));
            if ( ! add_content( error_403_form ) ) {
                return false;
            }
            break;
        //文件存在，200    
        case FILE_REQUEST:
            add_status_line(200, ok_200_title );
            add_headers(m_file_stat.st_size);
            //第一个iovec指针指向响应报文缓冲区，长度指向m_write_idx
            m_iv[ 0 ].iov_base = m_write_buf;
            m_iv[ 0 ].iov_len = m_write_idx;
            //第二个iovec指针指向mmap返回的文件指针，长度指向文件大小
            m_iv[ 1 ].iov_base = m_file_address;
            m_iv[ 1 ].iov_len = m_file_stat.st_size;
            m_iv_count = 2;
            return true;
        default:
            return false;
    }
	//除FILE_REQUEST状态外，其余状态只申请一个iovec，指向响应报文缓冲区
    m_iv[ 0 ].iov_base = m_write_buf;
    m_iv[ 0 ].iov_len = m_write_idx;
    m_iv_count = 1;
    return true;
}

```
### http_conn::write
服务器子线程调用process_write完成响应报文，随后注册epollout事件。服务器主线程检测写事件，并调用http_conn::write函数将响应报文发送给浏览器端。

该函数具体逻辑如下：

在生成响应报文时初始化byte_to_send，包括头部信息和文件数据大小。通过writev函数循环发送响应报文数据，根据返回值更新byte_have_send和iovec结构体的指针和长度，并判断响应报文整体是否发送成功。

* 若writev单次发送成功，更新byte_to_send和byte_have_send的大小，若响应报文整体发送成功,则取消mmap映射,并判断是否是长连接.
	* 长连接重置http类实例，注册读事件，不关闭连接，
	* 短连接直接关闭连接
* 若writev单次发送不成功，判断是否是写缓冲区满了。
	* 若不是因为缓冲区满了而失败，取消mmap映射，关闭连接
	* 若eagain则满了，更新iovec结构体的指针和长度，并注册写事件，等待下一次写事件触发（当写缓冲区从不可写变为可写，触发epollout），因此在此期间无法立即接收到同一用户的下一请求，但可以保证连接的完整性。
```
// 写HTTP响应
bool http_conn::write()
{
    int temp = 0;
    int bytes_have_send = 0;    // 已经发送的字节
    int bytes_to_send = m_write_idx;// 将要发送的字节 （m_write_idx）写缓冲区中待发送的字节数
    
    if ( bytes_to_send == 0 ) {
        // 将要发送的字节为0，这一次响应结束。
        modfd( m_epollfd, m_sockfd, EPOLLIN ); 
        init();
        return true;
    }

    while(1) {
        // 分散写
        temp = writev(m_sockfd, m_iv, m_iv_count);
        if ( temp <= -1 ) {
            // 如果TCP写缓冲没有空间，则等待下一轮EPOLLOUT事件，虽然在此期间，
            // 服务器无法立即接收到同一客户的下一个请求，但可以保证连接的完整性。
            if( errno == EAGAIN ) {
                modfd( m_epollfd, m_sockfd, EPOLLOUT );
                return true;
            }
            unmap();
            return false;
        }
        bytes_to_send -= temp;
        bytes_have_send += temp;
        if ( bytes_to_send <= bytes_have_send ) {
            // 发送HTTP响应成功，根据HTTP请求中的Connection字段决定是否立即关闭连接
            unmap();
            if(m_linger) {
                init();
                modfd( m_epollfd, m_sockfd, EPOLLIN );
                return true;
            } else {
                modfd( m_epollfd, m_sockfd, EPOLLIN );
                return false;
            } 
        }
    }
}
```